<template>
  <div class="thisweek">
    <a href="https://act.mogujie.com/zzlx67"></a>
    <img src="../../../assets/img/home/recommend_bg.jpg" alt="">
  </div>
</template>

<script>
export default {
  name:"ThisWeek"
}
</script>

<style scoped>
.thisweek img{
  width: 100%;
}
</style>