<template>
    <div class="feature">
        <a href="http://act.mogujie.com/zzlx67">
            <img src="~assets/img/home/recommend_bg.jpg" alt="">
        </a>
    </div>
</template>

<script>
export default {

}
</script>

<style>
    .feature img{
        width: 100%;
    }
</style>